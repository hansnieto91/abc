location <- read.csv("location.csv")
location$longitude <- sapply(location$rlng, function(x) if(is.factor(x)) {as.numeric(as.character(x))} else {x})
location$latitude <- sapply(location$rlat, function(x) if(is.factor(x)) {as.numeric(as.character(x))} else {x})
location$Anzahl <- sapply(location$Anzahl, function(x) if(is.factor(x)) {as.numeric(as.character(x))} else {x})

library(shiny)
library(leaflet)

ui <- bootstrapPage(
  
  tabsetPanel(
    tabPanel('Table',
             DT::DTOutput('mass_s_table')),
    tabPanel('Plot',
             absolutePanel(top = 0, right = 0, id = 'controls',
                           
                           sliderInput('nb_fatalities', 'Smart meter', 1, 10, 10),
                           
                           actionButton('show_about','About')                  
             ))),# las comas para que aparezca en la posicion correcta
  
  #  mainPanel(
  theme = shinythemes::shinytheme('simplex'),
  leaflet::leafletOutput('map', width = '100%', height = '100%'),
  
  tags$style(type = "text/css", "html, body {width:100%;height:100%}#controls{background-color:white;padding:0px;}"
  )
  #        )
  
) 


server <- function(input, output, session){
  
  observeEvent( input$show_about,{showModal(modalDialog("text_about", title='About'))})
  
  output$map <- 
    leaflet::renderLeaflet({
      
      subset(location,Anzahl%in%input$nb_fatalities)  %>% 
        leaflet() %>% setView( 10, 51, zoom = 5.) %>% addTiles() %>%addCircleMarkers(subset(location,Anzahl%in%input$nb_fatalities)$longitude, subset(location,Anzahl%in%input$nb_fatalities)$latitude, popup = ~ summary, radius = ~ sqrt(Anzahl)*3,fillColor = 'red', color = 'red', weight = 1)})
  
  output$mass_s_table <- DT::renderDT({
    subset(location,Anzahl%in%input$nb_fatalities)[3:5]
    
    
  })
  
}
shinyApp(ui, server)

